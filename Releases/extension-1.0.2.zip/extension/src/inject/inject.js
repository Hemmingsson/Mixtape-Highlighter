const clientID = 'client_id=27e7671d4d1784ed5d35d34922e136d8'
var twentyMinutes = 1200000

chrome.extension.sendMessage({}, function (response) {
  var readyStateCheckInterval = setInterval(function () {
    if (document.readyState === 'complete') {
      clearInterval(readyStateCheckInterval)
      init()
    }
  }, 10)
})

var init = function () {
  lookForMixtapes()
  onElementHeightChange(document.body, function () {
    lookForMixtapes()
  })
}

var lookForMixtapes = function () {
  console.log('Looking for Mixtapes...')
  var item = document.querySelectorAll('.soundList__item:not(.done), .seedSound__waveform:not(.done)')
  for (var i = item.length - 1; i >= 0; i--) {
    var url = item[i].getElementsByClassName('soundTitle__title')[0].href
    resolveSouncloudLink(item[i], url)
  }
}

function onElementHeightChange (elm, callback) {
  var lastHeight = elm.clientHeight
  var newHeight
  (function run () {
    newHeight = elm.clientHeight
    if (lastHeight !== newHeight) {
      callback()
    }
    lastHeight = newHeight
    if (elm.onElementHeightChangeTimer) {
      clearTimeout(elm.onElementHeightChangeTimer)
    }
    elm.onElementHeightChangeTimer = setTimeout(run, 200)
  })()
}

const resolveSouncloudLink = function (elm, url) {
  var resolveURL = 'https://api.soundcloud.com/resolve?url=' + url + '&' + clientID
  var request = new XMLHttpRequest()
  request.open('GET', resolveURL, true)
  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText)
      var isTrack = data.kind === 'track'
      var isLengthy = data.duration > twentyMinutes
      var isMixtape = isTrack && isLengthy
      elm.classList.add('done')
      if (isMixtape) {
        elm.classList.add('mixtape')
      }
    }
  }
  request.send()
}

